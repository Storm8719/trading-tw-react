import React from "react";

const Assets = (props) => {
    return <div>Assets will be here</div>
}

export default Assets;